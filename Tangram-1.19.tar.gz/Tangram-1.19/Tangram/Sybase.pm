use strict;

package Tangram::Sybase;

sub connect
  {
	shift;
	Tangram::Sybase::Storage->connect( @_ )
  }

use Tangram::Storage;

package Tangram::Sybase::Storage;

use base qw( Tangram::Storage );

$Tangram::Storage::storage_class{Sybase} = 'Tangram::Sybase::Storage';

sub prepare
  {
	my ($self, $sql) = @_;
	#print "prepare: $sql\n";
	bless [ $self, $sql ], 'Tangram::Sybase::Statement';
  }

*prepare_update = \*prepare;
*prepare_insert = \*prepare;

sub prepare_select
  {
	my ($self, $sql) = @_;
	return $self->prepare($sql);
  }

sub make_1st_id_in_tx
  {
    my ($self, $class_id) = @_;
    
	my $table = $self->{schema}{class_table};
	$self->sql_do("UPDATE $table SET lastObjectId = lastObjectId + 1 WHERE classId = $class_id");
	return $self->{db}->selectall_arrayref("SELECT lastObjectId from $table WHERE classId =  $class_id")->[0][0];
  }

package Tangram::Sybase::Statement;

sub execute
  {
	my $self = shift;
	my ($storage, $sql) = @$self;
	my $dbh = $storage->{db};
	$dbh->do($sql, {}, @_);
	#$sql =~ s/\?/$dbh->quote(shift)/ge; 
	#print "$sql\n";
	#$storage->sql_do($sql);

	

  }

sub finish
  {
  }

1;
